/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _WEAK_HASH_H
#define _WEAK_HASH_H

int weak_hash_check (hashcat_ctx_t *hashcat_ctx, hc_device_param_t *device_param, const u32 salt_pos);

#endif // _WEAK_HASH_H
